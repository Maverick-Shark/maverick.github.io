14:01 25/02/2024

Dear ZXTres user....  The time has come.

The MB2 has to be migrated to use.  Here are instructions:

Extract the contents of the zip file to the root of the SD card, overwriting MBUPD, MBINFO and BIT.

Only A35T and A200T are available in this initial packages, for some reason.  I think I just forgot.


Boot to ZXTres spectrum, then run the UPG2MIST.TAP utility to perform upgrade (4 Stages)

The mist menu should boot up automatically.  USB keyboards and PS2 keyboards are supported.

Ultimately it will be required to switch the USB switch on the dual mcu motherboard to the right - USB will be hosted on the main (midi) mcu, and will work with a greater number of devices.  For now keep it switched to the left.

Note:
In case of disaster where nothing works, just run UPG2MIST.TAP utility to revert changes

Thanks for reading :)

(2024) zx.micro.jack@gmail.com
