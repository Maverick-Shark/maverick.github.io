Example software in QLAY format suitable for the MiST.

The "QL Software Collection" has been moved to archive.org
