ZXTres Middleboard
==================

This is the main readme of the firmware for single and dual RP2040 middleboards.

Quick start
===========
1. unzip sdcard.zip to the root of any FAT32 formatted SD card (FAT16 should work but is untested)
2. copy ESXDOS tools also
3. copy ZX3 to /BIN/BPLUGINS/ZX3
4. copy BIT to /BIN/BPLUGINS/BIN
5. copy the upgradecore_aXXXt.ZX3 (or bit) appropriate to your board.
6. Run the zx3 (or .bit if it's working) from the F5 NMI browser.
7. Select *** Check & Upgrade ***
8. Select Flash all

Upgrade bootstraps
==================

IMPORTANT: Only do this if you are advised to do it.  If this process fails, then follow the section
first installation, or debricking process.

1. unzip sdcard.zip to the root of any FAT32 formatted SD card (FAT16 should work but is untested)
2. copy ESXDOS tools also
3. copy ZX3 to /BIN/BPLUGINS/ZX3
4. copy BIT to /BIN/BPLUGINS/BIN
5. copy the upgradecore_aXXXt.ZX3 (or bit) appropriate to your board.
6. Run the zx3 (or .bit if it's working) from the F5 NMI browser.
7. Select "Put MIDI in upgrade mode"
8. Select "Dangerous menu"
9. Select "!!! DANGER MODE SETTING !!!"
10. Select "*** DANGER MODE ***"
11. Do single upgrade
12. Scroll down (PGDN / PGUP) and select "RP2MBOOTBIN"
13. Do single upgrade
14. Scroll down (PGDN / PGUP) and select "RP2UBOOTBIN"



Notes
=====

Note: all new boards will have bootstrap pre-programmed in and should not need the debricking process described below.

The dual RP2040 middle boards, implement a 2 stage boot process, the first stage of which remains constant and 
should never need upgrading.  Because this remains static, and only the 2nd stage is upgraded, this makes it virtually impossible to brick during an upgrade.  (Though nothing is impossible in this crazy world.)

There are 7 images to upgrade in different locations on different chips, however, each build is signed so it 
cannot be programmed into the wrong place.  

As for normal use...  you can connect a USB hub to the USB port on the ZXTres, and to that connect a USB keyboard, mouse, and two joypads.

Please note that USB caters for a wide variety of devices, and level of functionality may vary at this stage.  
For example I have 4 USB keyboards.  3 are fine, one needs hotplugging after bootup to work.

For the joypads, I have to parse the USB descriptor to know how to map the axis and buttons - I'm sure not 
all combinations are working, but with cooperation from our wonderful community, I can refine the USB build 
to cater for more and more devices.

It also implements the functionality of the USB / PS2 keyboard of the +UNO.

For the moment, joypad movements are implemented as keypresses OPQA and WASD, but I will implement JAMMA 
shortly.  

Single RP2040 middleboards
==========================
Use the MSD upgrade method below to upload the RP2S build.  This build is provided to support those
few with the earlier boards.  These boards rely on the bootstrap written into the RP2040's ROM so 
just use the UF2 mechanism.  There being only one uC which is always connected to the USB makes it 
simpler to upgrade.

Dual RP2040 middleboards
========================
These boards have two RP2040s, in regular use, the USB is connected only to the keyboard / USB uC,
whereas the RP2040 in charge of MIDI and FPGA programming is isolated, except with a switch which is
provided only in case of emergency.

NOTE: This file only for single RP2040 board first edition that few people have.
rp2s.uf2 - build for single rp2040 middle board

NOTE: These files only required for manual updating of middleboard
uf2/rp2m-signed.uf2 - picosynth et al for midi rp2040
uf2/rp2u-signed.uf2 - usb et all for usb rp2040

uf2/ct2mgm8ba.uf2 - 2mb compressed soundfont fallback in case main soundfont breaks down
uf2/ct8mgm.uf2 - 8mb soundfont for picosynth
uf2/luttables.uf2 - look up tables for picosynth

sdcard.zip - unzip to fat32 partition on SD disk for use with upgradecore_aXXXt.bit.
rp2m-bootstrap.uf2 - bootstrap for midi rp2040 - switch usb switch to MIDI rp2040, hold button on bottom, copy to MSD device.
rp2u-bootstrap.uf2 - bootstrap for usb rp2040 - switch usb switch to USB rp2040, hold button on bottom, copy to MSD device

THEN: boot one of these with SD card with extracted files from sdcard.zip in the root.
upgradecore_a100t.bit/.ZX3 - update core for A100
upgradecore_a200t.bit/.ZX3 - update core for A200
upgradecore_a35t.bit/.ZX3 - update core for A35

Upgrade Core
------------

Start the FPGA via JTAG with the upgradecore_aXXXt.bit, and the following menu should be displayed (VGA only [sorry]).

 1  | Put MIDI in upgrade mode
 2  | Do single upgrade
 3  | Dangerous menu
 4  | Reset midi board
 5  | Reset all
 6  | Boot BIT file from card
 7  | *** Check & Upgrade ***

	Put MIDI in upgrade mode - exits MIDI app and sits in the bootstrap waiting for upgrade.
	Do single upgrade - performs upgrade file binary seperately.
	Dangerous menu - takes you deeper....
  Reset midi board - exits the bootstrap and reboots the midi board.  This is useful for booting cores.
  Reset all - resets all including the core.
  Boot BIT file from card - allows you to boot any .bit file from the SDcard
	Check & Upgrade - To next menu.


Under normal circumstances, you will always want to select option 7, Check & Upgrade, which takes you to
the following menu.

 1  | fpga 40 FF
 2  | usb  01.01y crc 0DE6
 3  | size 0000CAC8
 4  | midi 01.01y crc 0DE6
 5  | size 000116C8 blks 000
 6  | usbB 01.01
 7  | midB 01.00
 8  | Flash all
 9  | Boot recovery.bit
10  | Exit
11  | 
12  | 
13  |<

line 1 shows major minor version of USB image and integrity of build, along with CRC.
line 3 shows major minor version of MIDI image and integrity of build, along with CRC.
line 4 shows block status of LUTS, soundfont1, and soundfont2.  0 means good, 1 or 2 means its not there.
line 5 shows major minor version of bootstrap on USB rp2040
line 6 shows major minor version of bootstrap on MIDI rp2040

For software on the middleboard to be in a good state:
	usb and midi have to show a sensible major minor version and a 'y' indicating the image is intact
	blks have to be '000'

Select Flash All, to update all, Exit to reset and return to ZXTres flash core.  Line 13 takes you to the original
menu:

Dangerous menu
--------------
	Put Midi in MSD mode - boots rp2040 to MSD flash mode - useful to upgrade just the midi app / bootstrap without affecting usb flash.  
      Probably only useful for development.
	Put Midi in dangerous mode - removes write protection from bootstrap, so bootstrap can be upgraded - this can leave us with a brick - 
      requiring JTAG to debrick.
	Run core (LBA) - runs a core from the SD card selected by LBA
	Run core (FN) - runs a core from the SD card selected by filename

To upgrade the bootstrap on either rp2040, place Midi in dangerous mode (see Dangerous menu), then 'perform upgrade', and select the RP2MBOOT.BIN or RP2UBOOT.BIN.
If this fails for any reason, then you will have to use the MSD upgrade mechanism, so take care.

MSD upgrade mechanism
---------------------
Hold the button on the bottom of the ZXTres while connecting a USB-A to USB-A cable to your PC.  A USB MSD drive should appear on the PC.  Copy the UF2 file onto 
this new drive, and after a period of time (the bigger the file the longer), it will disappear, and reboot.

First installation, or debricking process
-----------------------------------------
(Note: All boards will be shipped with bootstraps already written on - this procedure is provided only for
the sake of debricking, or for production.)

If you received a middleboard with no firmware running, which can be identified by running the upgrade core, and most of the fields will read a series of FF.

  +------------------------------------------+
  |               oo o        Antonio        |
  |  SWITCH       oo o          Villena      |
  |               oo o        Middle board   |
  |               oo o                     o |
  |               oo o                     o |
  |               oo o                     o |
  |               oo o                     o |
  |               oo o                     o |
  |               oo o                     o |
  |               oo o                     o |
  |               oo o                     o |
  |                  o                     o |
  +------------------------------------------+

This will require switching the switch to the right with the middle board writing on the PCB reading left to right, and the single row of connectors on the right, connect USB while pressing the button on the underside of the ZXTres board.  Copy rp2m-bootstrap.uf2 to the MSD drive that appears (see MSD upgrade 
mechanism).  Power down.  Switch now to the left, and repeat the process this time, but this time copy rp2u-bootstrap.uf2 to the MSD drive.  This process should
never need to be repeated.  

Now use an SD card formatted with FAT32 file system, and unpack the zip file *prod.zip* into the root directory.

Put the board back together, connect JTAG, and boot upgradecore_aXXXt.bit replacing XXX with the FPGA board appropriate with your 
model.  The upgrade menu should appear (see Upgrade Core) - select Flash all.

Ensure the status menu reads something similar to below:

 2  | usb  01.XXy crc XXXX
 3  | size 0000XXXX
 4  | midi 01.XXy crc XXXX
 5  | size 000XXXXX blks 000

blks should be 000, and the letter after the usb version and the midi version string should be 'y', otherwise repeat the flash all process.

Known issues
------------
- Some USB devices may not start up properly from cold, these may require hotplugging to fix - it may be fixed
  with a higher amp PSU, and placing a usb hub inbetween has been known to work, though the cause is not yet
  understood
  
